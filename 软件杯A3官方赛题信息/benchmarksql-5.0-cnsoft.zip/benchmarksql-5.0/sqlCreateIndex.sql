create index ndx_customer_name on BENCHMARKSQL.BMSQL_customer (c_w_id, c_d_id,c_last, c_first);
create or replace procedure BENCHMARKSQL.createsequence
as
    n int;
    stmt1 varchar(200);
    begin
        select count(*)+1 into n from BMSQL_history;
        if(n != 1) then
            select max(hist_id) + 1 into n from BMSQL_history;
        end if;
        PRINT n;
        stmt1:='create sequence hist_id_seq start with '||n||' MAXVALUE 9223372036854775807 CACHE 50000;';
        EXECUTE IMMEDIATE stmt1;
end;
/ 
call BENCHMARKSQL.createsequence;
alter table BENCHMARKSQL.BMSQL_history modify hist_id integer default (BENCHMARKSQL.hist_id_seq.nextval);
exit;

